package staff_members;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Implements the {@link StaffMemberCollection} interface using an underlying map allowing the number of occurrences of each added staff member to be counted.
 * 
 * If the same staff member is added more than once, then it is not re-added, but its occurrence count is increased.
 * 
 * Edit this file to pass the PART5 tests.
 * 
 * @author mdixon
 */
public class StaffMemberMap implements StaffMemberCollection {

	/**
	 * A collection which maps contained staff members to an occurrence count.
	 */
	private Map<StaffMember, Integer> staffMembers = new HashMap<>(); // TODO PART5 : create a suitable map instance

	///////////////////////////////////////////////////////////////////////

	@Override
	public int addStaffMember(StaffMember staffMember) {

		// TODO PART5 : add the staff member to the map setting the correct associated occurrence count
		// if the staff member was not already in the map, set the associated count to 1
		// otherwise increase the existing occurrence count.
		// finally, return the total number of key/value pairs in the map
		if (!staffMembers.containsKey(staffMember)) {
			staffMembers.put(staffMember, 1);
		} else {
			int currentCount = staffMembers.get(staffMember);
			staffMembers.put(staffMember, currentCount + 1);
		}
		return staffMembers.size();
	}

	@Override
	public boolean removeStaffMember(StaffMember staffMember) {

		// TODO PART5 : remove the staff member if it exists and return true. Return false if it does not exist.
		if(staffMembers.containsKey(staffMember)) {
			staffMembers.remove(staffMember);
			return true;
		}
		return false;
	}

	@Override
	public boolean containsStaffMember(StaffMember staffMember) {

		// TODO PART5 : check if the map contains the given staff member as a key
		
		return staffMembers.containsKey(staffMember);
	}

	@Override
	public int countStaffMembers() {

		// TODO PART5 : return the number of key/value pairs in the map
		return staffMembers.size();
	}

	@Override
	public void clearAllStaffMembers() {

		// TODO PART5 : remove all staff members from the map
		staffMembers.clear();
	}

	@Override
	public int indexOfStaffMember(StaffMember staffMember) {

		// TODO PART5 : throw correct exception which indicates this is an unsupported operation
		
		throw new UnsupportedOperationException();
	}

	@Override
	public StaffMember getHighestSalary() {

		// TODO PART5 : iterate the map, and find the staff member with the highest salary
		if (staffMembers.isEmpty()) return null;

		StaffMember highest = null;
		for(Map.Entry<StaffMember, Integer> data: staffMembers.entrySet()) {
			if (highest == null || data.getKey().getSalary() > highest.getSalary()) {
				highest = data.getKey();
			}
		}
		return highest;
	}

	@Override
	public StaffMember getLowestSalary() {

		// TODO PART5 : iterate the map, and find the staff member with the smallest salary
		if (staffMembers.isEmpty()) return null;

		StaffMember lowest = null;
		for(Map.Entry<StaffMember, Integer> data: staffMembers.entrySet()) {
			if (lowest == null || data.getKey().getSalary() < lowest.getSalary()) {
				lowest = data.getKey();
			}
		}
		return lowest;
	}

	@Override
	public float getTotalBonus() {

		// TODO PART5 : iterate over the map, totalling the bonus of each staff member, then return this value
		float bonus = 0;
		for(Map.Entry<StaffMember, Integer> data: staffMembers.entrySet()) {
			bonus += data.getKey().getBonus() * data.getValue();
		}
		return bonus;
	}

	/**
	 * Gets the staff member which has the highest occurrence count (i.e. has been added to the collection the most number of times).
	 * 
	 * @return the staff member which has been added to the collection the most number of times, null if no staff members exist within the collection.
	 */
	public StaffMember getMostCommonStaffMember() {

		// streams based solution also valid	
		if (staffMembers == null || staffMembers.isEmpty()) {
	        return null;
	    }

	    Map.Entry<StaffMember, Integer> mostCommon = null;

	    for (Map.Entry<StaffMember, Integer> entry : staffMembers.entrySet()) {
	        if (mostCommon == null || entry.getValue() > mostCommon.getValue()) {
	            mostCommon = entry;
	        }
	    }

	    return mostCommon.getKey();
	}

	/**
	 * Gets the occurrence count of the most common staff member.
	 * 
	 * @return the occurrence count of the most common staff member, 0 if no staff members exist within the collection.
	 */
	public int getMostCommonStaffMemberCount() {

		// TODO PART5 : get and return the occurrence count of the most common staff member, 0 if none exist within the collection.
		if (staffMembers == null || staffMembers.isEmpty()) {
			return 0;
		}

		Entry<StaffMember, Integer> mostCommon = null; 
		for(Map.Entry<StaffMember, Integer> data : staffMembers.entrySet()) {
			if(mostCommon == null || data.getValue() > mostCommon.getValue()) {
				mostCommon = data;
			}
		}

		// TODO PART5 : iterate the map and find the staff member with the highest occurrence count
		
		return mostCommon.getValue();

	}

	///////////////////////////////////////////////////////////////////////

}

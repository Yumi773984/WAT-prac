package staff_members;

/**
 * A type of {@link StaffMember} which is employed full-time
 * 
 * Edit this file to pass the PART1 tests.
 * 
 */
public class FullTimeEmployee extends StaffMember {

	/**
	 * The department in which the full-time employee works.
	 */
	private String department;

	////////////////////////////////////////////

	@Override
	public float getBonus() {
		// TODO Part1: calculate and return the bonus, which is half their salary
		
		return (float) (0.5 * salary);
	}

	@Override
	public boolean isFullTime() {

		// TODO Part1: return a boolean type value indicating that the employee is full-time 
		return true;
	}

	/**
	 * Gets the department in which the full-time employee works.
	 * 
	 * @return the department in which the full-time employee works.
	 */
	public String getDepartment() {

		// TODO Part1: return the correct attribute
		return department;
	}

	/**
	 * Sets the department in which the full-time employee works.
	 * 
	 * @param department the department in which the full-time employee works.
	 */
	public void setDepartment(String department) {

		// TODO Part1: set the correct attribute
		this.department = department;
	}	

	/**
	 * Clears the name of the department in which the employee works to be an empty string.
	 */
	public void clearDepartment() {

		// TODO Part1: set the correct attribute to be an empty string
		this.department = "" ;
	}

	/**
	 * Constructor
	 *
	 * A full-time employee has an initial salary of 14000
	 * 
	 * The {@link #department} attribute should initially be set to "tbc"
	 * 
	 * @param name    the name of the employee
	 * @param address the address of the employee
	 * @param staffNo the unique staff member number
	 */
	public FullTimeEmployee(String name, String address, int staffNo) {

		// TODO Part1: pass name, address, staffNo to the super() type, along with the correct salary value (as specified in the constructor comment).
		super(name, address, staffNo, 14000);

		// TODO Part1: set 'department' to the correct initial value (specified in the constructor comment).
		this.department = "tbc";
	}

}


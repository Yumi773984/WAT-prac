package staff_members;

/**
 * A type of {@link StaffMember} which is a director of the company
 * 
 * Edit this file to pass the PART2 tests.
 * 
 */
public class CompanyDirector extends StaffMember {

	/**
	 * The number of shares owned by a director
	 */
	private int shares;

	/**
	 * Flag indicating whether the director works full-time.
	 */
	private boolean isFullTime;

	/**
	 * Flag indicating whether the director also owns part of the company.
	 */
	private boolean isOwner = true;

	////////////////////////////////////////////////////////////

	@Override
	public float getBonus() {
		// TODO Part2: calculate and return the bonus, which is three times the salary for a director
		float bonus = salary * 3;
		return bonus;
	}

	@Override
	public boolean isFullTime() {

		// TODO Part2: return the correct attribute, indicating whether the director is full time.
		
		return isFullTime;
	}

	/**
	 * 
	 * @return flag indicating whether the director also owns part of the company.
	 */
	public boolean isOwner() {
		// TODO Part2: return the correct attribute, indicating whether the director is an owner of the company.

		return isOwner;
	}

	/**
	 * @param isOwner a flag indicating whether the director also owns part of the company.
	 */
	public void setOwnership(boolean isOwner) {
		// TODO Part2: set the correct attribute
		this.isOwner = isOwner;
	}

	/**
	 * Sets the director to be full-time
	 */
	public void setFullTime() {

		// TODO Part2: set the correct attribute to true
		this.isFullTime = true;
	}

	/**
	 * Sets the director to be part-time
	 */
	public void setPartTime() {

		// TODO Part2: set the correct attribute to false
		this.isFullTime = false;
	}

	/**
	 * @return the number of shares owned by a director
	 */
	public int getShares() {

		// TODO Part2: return the correct attribute
		return shares;
	}

	/**
	 * Doubles the amount of share owned by the director
	 * 
	 * @return the number of shares owned by a director (once doubled)
	 */
	public int doubleShares() {

		// TODO Part2: double the number of shares and return the value
		shares = shares * 2;
		return shares;
	}

	/**
	 * Halves the amount of share owned by the director
	 * 
	 * If the director is an owner, then the number of shares should NOT be changed.
	 * 
	 * @return the number of shares owned by a director (once updated as required)
	 */
	public int halfShares() {

		// TODO Part2: half the number of shares (if the director is NOT an owner), then return the value
		if(isOwner) {
			return  shares;
		}
		else {
			shares = shares / 2;
			return shares;
		}
	}

	/**
	 * Constructor
	 *
	 * A director has an initial salary of 100000
	 * 
	 * A director initially owns 20 shares.
	 * 
	 * A director is initially set on as a full-time employee.
	 * 
	 * A director is initially set to NOT be an owner.
	 * 
	 * @param name    the name of the director
	 * @param address the address of the director
	 * @param staffNo the unique staff member number
	 */
	public CompanyDirector(String name, String address, int staffNo) {

		// TODO Part2: pass correct attributes to the super type, along with the correct salary value (as specified in the constructor comment).
		super(name, address, staffNo, 100000);

		// TODO Part2: set the 'shares', 'isFullTime' and 'isOwner' attributes (as specified in the constructor comment).
		this.shares = 20;
		this.isFullTime = true;
		this.isOwner = false;
	}
}

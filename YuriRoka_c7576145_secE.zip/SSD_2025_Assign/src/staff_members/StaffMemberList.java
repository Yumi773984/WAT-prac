package staff_members;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Implements the {@link StaffMemberCollection} interface using an underlying ordered list.
 * 
 * Edit this file to pass the PART4 tests.
 * 
 * @author mdixon
 */
public class StaffMemberList implements StaffMemberCollection {

	/**
	 * The list of staff members
	 */
	private List<StaffMember> staffMembers = new ArrayList<StaffMember>();

	///////////////////////////////////////////////////////////////////////

	@Override
	public int addStaffMember(StaffMember staffMember) {

		// TODO Part4: add to the list, and return the size

		staffMembers.add(staffMember);
		return staffMembers.size();
	}

	@Override
	public boolean removeStaffMember(StaffMember staffMember) {

		// TODO Part4: remove the staff member from the list, returning true if actually found and removed
		boolean result = (staffMembers.contains(staffMember)) ? staffMembers.remove(staffMember) : false;
		return result;
	}

	@Override
	public boolean containsStaffMember(StaffMember staffMember) {

		// TODO Part4: return true if the staff member is contained within the list
		
		return staffMembers.contains(staffMember);
	}

	@Override
	public int countStaffMembers() {

		// TODO Part4: return the number of staff members in the list
		
		return staffMembers.size();
	}

	@Override
	public void clearAllStaffMembers() {

		// TODO Part4: clear the list contents
		staffMembers.removeAll(staffMembers);
	}

	@Override
	public int indexOfStaffMember(StaffMember staffMember) {

		// TODO Part4: return the index of the staff member within the list (if it exists), <0 otherwise
		
		return staffMembers.indexOf(staffMember);
	}

	@Override
	public StaffMember getHighestSalary() {	
		if(staffMembers.isEmpty()) {
			return null;
		}

		StaffMember largest = staffMembers.get(0);
		for (StaffMember sm : staffMembers) {

			// TODO Part4: compare the salary of 'sm' against the 'salary', if it is higher then record 'sm' as the 'largest' so far
			if(sm.getSalary() > largest.getSalary()) {
				largest = sm;
			}
		}

		return largest;
	}

	@Override
	public StaffMember getLowestSalary() {
		
		if(staffMembers.isEmpty()) {
			return null;
		}

		// TODO Part4: iterate over the list, finding the staff member with the lowest salary, then return this staff member
		StaffMember least = staffMembers.get(0);
		for(StaffMember sm : staffMembers) {
			if(sm.getSalary() < least.getSalary()) {
				least = sm;
			}
		}
		return least;
	}

	@Override
	public float getTotalBonus() {

		float bonus = 0;

		// TODO Part4: iterate over the list, totalling the bonus of each staff member, then return this value
		for(StaffMember sm : staffMembers) {
			bonus = bonus + sm.getBonus();
		}
		return bonus;
	}

	/**
	 * Sorts the list of staff members based on their salary (lowest to highest)
	 */
	public void sortOnSalary() {
		// TODO Part4: sort the list, comparing the staff members on their salary
		staffMembers.sort((a, b) -> Float.compare(a.getSalary(), b.getSalary())); 
	}
}

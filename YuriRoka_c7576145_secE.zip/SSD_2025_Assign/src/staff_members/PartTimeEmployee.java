package staff_members;

/**
 * A type of {@link StaffMember} which is employed part-time
 * 
 * Edit this file to pass the PART3 tests.
 * 
 */
public class PartTimeEmployee extends StaffMember {

	/**
	 * The minimum hourly rate paid to any part-time employee.
	 */
	public final static float MINIMUM_RATE = 11.62f;

	/**
	 * The current hourly rate of the part-time employee.
	 */
	private float hourlyRate;

	///////////////////////////////////////////////

	@Override
	public float getBonus() {
		// TODO Part3: calculate and return the bonus, which is 20% of their salary, plus twice their hourly rate
		float bonus = (0.2f * salary) + (2 * hourlyRate);
		return bonus;
	}

	@Override
	public boolean isFullTime() {
		// TODO Part3: return a boolean type value indicating that the employee is not full-time

		return false;
	}

	/**
	 * 
	 * @return the hourly rate of the part-time employee.
	 */
	public float getHourlyRate() {
		// TODO Part3: return correct attribute
		
		return hourlyRate;
	}

	/**
	 * 
	 * @return the minimum hourly rate paid to any part-time employee.
	 */
	public float getMinimumHourlyRate() {

		// TODO Part3: return correct attribute

		return MINIMUM_RATE;
	}

	/**
	 * Increments the hourly rate of the part-time employee.
	 * 
	 * If the hourly rate exceeds 10% of their salary, then it is set to be exactly 10% of their salary.
	 * 
	 * @param amount the amount to increment the hourly rate
	 * @return the updated hourly rate
	 */
	public double incHourlyRate(float amount) {

		// TODO Part3: increment the hourly rate (ensuring it does not exceed 10% of the salary), then return the result
		hourlyRate += amount;
		
		if(hourlyRate > (0.1f * salary)) {
			hourlyRate = 0.1f * salary;
			return hourlyRate;
		}
		else {
			return hourlyRate; 
		}
	}

	/**
	 * Decrements the hourly rate of the part-time employee.
	 * 
	 * If the hourly rate drops below {@link #MINIMUM_RATE} then it should remain as the {@link #MINIMUM_RATE}
	 * 
	 * @param amount the amount to increment the hourly rate
	 * @return the updated hourly rate
	 */
	public double decHourlyRate(float amount) {

		// TODO Part3: decrement the hourly rate (ensuring it does not go below the MINIMUM_RATE), then return the result
		hourlyRate -= amount;
		if(hourlyRate < MINIMUM_RATE) {
			hourlyRate = MINIMUM_RATE;
		}
		return hourlyRate;
	}

	/**
	 * Resets the hourly rate back to the default (see constructor comments).
	 */
	public void resetHourlyRate() {

		// TODO Part3: re-set hourly rate
		this.hourlyRate = 12;
	}

	/**
	 * Constructor
	 *
	 * A part-time employee has an initial salary of 2000
	 * 
	 * A part-time employee has an initial hourly rate of 12
	 * 
	 * @param name    the name of the employee
	 * @param address the address of the employee
	 * @param staffNo the unique staff member number
	 */
	public PartTimeEmployee(String name, String address, int staffNo) {

		// TODO Part3: pass correct attributes to the super type, along with the correct salary value (as specified in the constructor comment).
		super(name, address, staffNo, 2000);

		// TODO Part3: set hourly rate (as specified in the constructor comment).
		this.hourlyRate = 12;
	}

}
